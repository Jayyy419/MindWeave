/**
 * Central framework configuration — the single source of truth for all
 * AI reframing frameworks in MindWeave.
 *
 * To add a new framework:
 *   1. Add a new entry to FRAMEWORK_CONFIGS below.
 *   2. Add its label to FRAMEWORK_LABELS in frontend/src/pages/HistoryPage.tsx.
 *   3. Add its value to the FRAMEWORKS array in frontend/src/pages/HomePage.tsx.
 *   4. Extend the union type in frontend/src/services/api.ts.
 *   (Backend routes and AI service pick up the new framework automatically.)
 */
export interface FrameworkConfig {
    id: string;
    label: string;
    /** Full system prompt sent as the Gemini systemInstruction (separate from user text). */
    systemPrompt: string;
    /** Offline fallback reframing text used when the Gemini API is unavailable. */
    fallback: string;
}
export declare const FRAMEWORK_CONFIGS: FrameworkConfig[];
/** Array of valid framework ID strings — used for input validation in routes. */
export declare const VALID_FRAMEWORK_IDS: string[];
/** Map from framework ID to its Gemini system prompt. */
export declare const FRAMEWORK_PROMPT_MAP: Record<string, string>;
/** Map from framework ID to its offline fallback text. */
export declare const FRAMEWORK_FALLBACK_MAP: Record<string, string>;
//# sourceMappingURL=frameworks.d.ts.map