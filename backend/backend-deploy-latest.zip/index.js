"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const cors_1 = __importDefault(require("cors"));
const dotenv_1 = __importDefault(require("dotenv"));
const entries_1 = __importDefault(require("./routes/entries"));
const user_1 = __importDefault(require("./routes/user"));
const thinktanks_1 = __importDefault(require("./routes/thinktanks"));
const auth_1 = __importDefault(require("./routes/auth"));
const auth_2 = require("./middleware/auth");
// Load environment variables
dotenv_1.default.config();
const app = (0, express_1.default)();
const PORT = parseInt(process.env.PORT || "3001", 10);
const CORS_ORIGIN = process.env.CORS_ORIGIN || "*";
// Middleware
app.use((0, cors_1.default)({
    origin: CORS_ORIGIN === "*" ? true : CORS_ORIGIN,
}));
app.use(express_1.default.json());
// Health check (no auth required)
app.get("/", (_req, res) => {
    res.status(200).send("MindWeave backend is running");
});
app.get("/api/health", (_req, res) => {
    res.json({ status: "ok", timestamp: new Date().toISOString() });
});
// Authentication routes (no auth middleware required)
app.use("/api/auth", auth_1.default);
// All API routes require anonymous user identification
app.use("/api/entries", auth_2.authMiddleware, entries_1.default);
app.use("/api/user", auth_2.authMiddleware, user_1.default);
app.use("/api/thinktanks", auth_2.authMiddleware, thinktanks_1.default);
// Start server
app.listen(PORT, () => {
    console.log(`MindWeave backend running at http://localhost:${PORT}`);
});
//# sourceMappingURL=index.js.map