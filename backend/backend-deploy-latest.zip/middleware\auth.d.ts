import { Request, Response, NextFunction } from "express";
/**
 * Middleware that extracts the anonymous user ID from the `x-anonymous-id` header.
 * If the user doesn't exist in the database yet, creates a new User record.
 * Attaches the internal user ID to `req.userId` for downstream use.
 */
export declare function authMiddleware(req: Request, res: Response, next: NextFunction): Promise<void>;
//# sourceMappingURL=auth.d.ts.map