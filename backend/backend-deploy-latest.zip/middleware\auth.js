"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.authMiddleware = authMiddleware;
const client_1 = require("@prisma/client");
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const prisma = new client_1.PrismaClient();
const JWT_SECRET = process.env.JWT_SECRET || "mindweave-dev-secret";
/**
 * Middleware that extracts the anonymous user ID from the `x-anonymous-id` header.
 * If the user doesn't exist in the database yet, creates a new User record.
 * Attaches the internal user ID to `req.userId` for downstream use.
 */
async function authMiddleware(req, res, next) {
    const authorization = req.headers.authorization;
    if (authorization?.startsWith("Bearer ")) {
        try {
            const token = authorization.substring("Bearer ".length);
            const payload = jsonwebtoken_1.default.verify(token, JWT_SECRET);
            const user = await prisma.user.findUnique({ where: { id: payload.userId } });
            if (!user) {
                res.status(401).json({ error: "Invalid authentication token" });
                return;
            }
            req.userId = user.id;
            req.username = user.username || `User-${user.id.substring(0, 6)}`;
            next();
            return;
        }
        catch {
            res.status(401).json({ error: "Invalid or expired token" });
            return;
        }
    }
    // Backward-compatible anonymous mode for existing clients.
    const anonymousId = req.headers["x-anonymous-id"];
    if (!anonymousId) {
        res.status(401).json({ error: "Missing authentication token" });
        return;
    }
    // Find or create the user based on anonymous ID
    let user = await prisma.user.findUnique({
        where: { anonymousId },
    });
    if (!user) {
        user = await prisma.user.create({
            data: { anonymousId },
        });
    }
    // Attach the internal user ID to the request object
    req.userId = user.id;
    req.username = user.username || `User-${user.id.substring(0, 6)}`;
    next();
}
//# sourceMappingURL=auth.js.map