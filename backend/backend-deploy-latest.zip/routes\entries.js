"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const client_1 = require("@prisma/client");
const gemini_1 = require("../services/gemini");
const gamification_1 = require("../services/gamification");
const frameworks_1 = require("../config/frameworks");
const router = (0, express_1.Router)();
const prisma = new client_1.PrismaClient();
const MAX_ENTRY_WORDS = 100;
const OFF_TOPIC_ERROR = "MindWeave is a personal journaling tool. Please write about your own thoughts, feelings, and experiences.";
function countWords(value) {
    const trimmed = value.trim();
    if (!trimmed)
        return 0;
    return trimmed.split(/\s+/).length;
}
/**
 * POST /api/entries/reframe-preview
 * Generate a live reframing preview without saving to database.
 *
 * Body: { text: string, framework: "cbt" | "iceberg" | "growth" }
 */
router.post("/reframe-preview", async (req, res) => {
    const { text, framework } = req.body;
    if (!text || typeof text !== "string" || text.trim().length === 0) {
        res.status(400).json({ error: "text is required and must be a non-empty string" });
        return;
    }
    if (!framework || !frameworks_1.VALID_FRAMEWORK_IDS.includes(framework)) {
        res.status(400).json({
            error: `framework must be one of: ${frameworks_1.VALID_FRAMEWORK_IDS.join(", ")}`,
        });
        return;
    }
    if (text.length > 5000) {
        res.status(400).json({ error: "text must be 5000 characters or fewer" });
        return;
    }
    if (countWords(text) > MAX_ENTRY_WORDS) {
        res.status(400).json({ error: `text must be ${MAX_ENTRY_WORDS} words or fewer` });
        return;
    }
    try {
        const reframedText = await (0, gemini_1.reframeText)(text.trim(), framework, { allowFallback: false });
        res.json({
            originalText: text.trim(),
            reframedText,
            framework,
            source: "ai",
        });
    }
    catch (error) {
        if (error instanceof Error && error.message === "NOT_JOURNAL_ENTRY") {
            res.status(422).json({ error: OFF_TOPIC_ERROR });
            return;
        }
        console.error("Error generating reframe preview:", error);
        res.status(503).json({ error: "Live AI reframing is temporarily unavailable" });
    }
});
/**
 * POST /api/entries
 * Create a new journal entry with AI reframing and tag extraction.
 *
 * Body: { text: string, framework: "cbt" | "iceberg" | "growth" }
 * Returns the created entry with reframed text.
 */
router.post("/", async (req, res) => {
    const userId = req.userId;
    const { text, framework } = req.body;
    // Validate input
    if (!text || typeof text !== "string" || text.trim().length === 0) {
        res.status(400).json({ error: "text is required and must be a non-empty string" });
        return;
    }
    if (!framework || !frameworks_1.VALID_FRAMEWORK_IDS.includes(framework)) {
        res.status(400).json({
            error: `framework must be one of: ${frameworks_1.VALID_FRAMEWORK_IDS.join(", ")}`,
        });
        return;
    }
    // Limit text length to prevent abuse
    if (text.length > 5000) {
        res.status(400).json({ error: "text must be 5000 characters or fewer" });
        return;
    }
    if (countWords(text) > MAX_ENTRY_WORDS) {
        res.status(400).json({ error: `text must be ${MAX_ENTRY_WORDS} words or fewer` });
        return;
    }
    try {
        // Validate journal intent first, then extract tags in parallel.
        // reframeText throws NOT_JOURNAL_ENTRY if the content is off-topic.
        const [reframedText, tags] = await Promise.all([
            (0, gemini_1.reframeText)(text.trim(), framework),
            (0, gemini_1.extractTags)(text.trim()),
        ]);
        // Save entry to database
        const entry = await prisma.entry.create({
            data: {
                userId,
                framework,
                originalText: text.trim(),
                reframedText,
                tags: JSON.stringify(tags),
            },
        });
        // Update user gamification (level, badges, tags)
        await (0, gamification_1.updateUserGamification)(userId, tags);
        res.status(201).json({
            id: entry.id,
            framework: entry.framework,
            originalText: entry.originalText,
            reframedText: entry.reframedText,
            tags,
            createdAt: entry.createdAt,
        });
    }
    catch (error) {
        if (error instanceof Error && error.message === "NOT_JOURNAL_ENTRY") {
            res.status(422).json({ error: OFF_TOPIC_ERROR });
            return;
        }
        console.error("Error creating entry:", error);
        res.status(500).json({ error: "Failed to create entry. Please try again." });
    }
});
/**
 * GET /api/entries
 * List all entries for the current user, ordered by newest first.
 * Returns a preview (first 120 chars) of each entry.
 */
router.get("/", async (req, res) => {
    const userId = req.userId;
    try {
        const entries = await prisma.entry.findMany({
            where: { userId },
            orderBy: { createdAt: "desc" },
            select: {
                id: true,
                framework: true,
                originalText: true,
                createdAt: true,
            },
        });
        // Return entries with a text preview
        const result = entries.map((e) => ({
            id: e.id,
            framework: e.framework,
            preview: e.originalText.length > 120
                ? e.originalText.substring(0, 120) + "..."
                : e.originalText,
            createdAt: e.createdAt,
        }));
        res.json(result);
    }
    catch (error) {
        console.error("Error listing entries:", error);
        res.status(500).json({ error: "Failed to list entries" });
    }
});
/**
 * GET /api/entries/:id
 * Get a single entry by ID. Only returns entries belonging to the current user.
 */
router.get("/:id", async (req, res) => {
    const userId = req.userId;
    const id = req.params.id;
    try {
        const entry = await prisma.entry.findFirst({
            where: { id, userId },
        });
        if (!entry) {
            res.status(404).json({ error: "Entry not found" });
            return;
        }
        res.json({
            id: entry.id,
            framework: entry.framework,
            originalText: entry.originalText,
            reframedText: entry.reframedText,
            tags: JSON.parse(entry.tags),
            createdAt: entry.createdAt,
        });
    }
    catch (error) {
        console.error("Error fetching entry:", error);
        res.status(500).json({ error: "Failed to fetch entry" });
    }
});
/**
 * DELETE /api/entries
 * Delete multiple entries owned by the current user.
 * Body: { ids: string[] }
 */
router.delete("/", async (req, res) => {
    const userId = req.userId;
    const { ids } = req.body;
    if (!Array.isArray(ids) || ids.length === 0) {
        res.status(400).json({ error: "ids must be a non-empty array" });
        return;
    }
    const sanitizedIds = ids
        .filter((id) => typeof id === "string" && id.trim().length > 0)
        .map((id) => id.trim());
    if (sanitizedIds.length === 0) {
        res.status(400).json({ error: "ids must contain valid entry IDs" });
        return;
    }
    try {
        const result = await prisma.entry.deleteMany({
            where: {
                userId,
                id: { in: sanitizedIds },
            },
        });
        res.json({ deletedCount: result.count });
    }
    catch (error) {
        console.error("Error deleting multiple entries:", error);
        res.status(500).json({ error: "Failed to delete selected entries" });
    }
});
/**
 * DELETE /api/entries/:id
 * Delete one entry owned by the current user.
 */
router.delete("/:id", async (req, res) => {
    const userId = req.userId;
    const id = req.params.id;
    try {
        const deleted = await prisma.entry.deleteMany({
            where: { id, userId },
        });
        if (deleted.count === 0) {
            res.status(404).json({ error: "Entry not found" });
            return;
        }
        res.status(204).send();
    }
    catch (error) {
        console.error("Error deleting entry:", error);
        res.status(500).json({ error: "Failed to delete entry" });
    }
});
exports.default = router;
//# sourceMappingURL=entries.js.map