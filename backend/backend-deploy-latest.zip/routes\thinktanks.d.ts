declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=thinktanks.d.ts.map