"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const client_1 = require("@prisma/client");
const router = (0, express_1.Router)();
const prisma = new client_1.PrismaClient();
/**
 * GET /api/user/profile
 * Returns the current user's profile: level, badges, tags, and entry count.
 */
router.get("/profile", async (req, res) => {
    const userId = req.userId;
    try {
        const user = await prisma.user.findUnique({
            where: { id: userId },
        });
        if (!user) {
            res.status(404).json({ error: "User not found" });
            return;
        }
        const entryCount = await prisma.entry.count({ where: { userId } });
        res.json({
            level: user.level,
            badges: JSON.parse(user.badges),
            tags: JSON.parse(user.tags),
            entryCount,
            createdAt: user.createdAt,
        });
    }
    catch (error) {
        console.error("Error fetching profile:", error);
        res.status(500).json({ error: "Failed to fetch profile" });
    }
});
exports.default = router;
//# sourceMappingURL=user.js.map