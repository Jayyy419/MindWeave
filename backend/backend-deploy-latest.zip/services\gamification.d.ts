/**
 * Calculate user level based on entry count.
 * Level = floor(entryCount / 5) + 1
 * (1-4 entries = level 1, 5-9 = level 2, etc.)
 */
export declare function calculateLevel(entryCount: number): number;
/**
 * Determine which badges the user has earned.
 * Returns an array of badge name strings.
 */
export declare function calculateBadges(userId: string): Promise<string[]>;
/**
 * Merge new tags into the user's existing tag list (deduplicated).
 */
export declare function mergeTags(existingTagsJson: string, newTags: string[]): string[];
/**
 * Update user's level, badges, and tags after a new entry is created.
 */
export declare function updateUserGamification(userId: string, newTags: string[]): Promise<void>;
//# sourceMappingURL=gamification.d.ts.map