/**
 * Reframe a user's journal entry text using the specified therapeutic framework.
 * Calls Google Gemini to generate the reframed version.
 *
 * Throws Error("NOT_JOURNAL_ENTRY") when the model determines the text is not
 * a genuine personal journal entry (off-topic / abuse attempt). This error is
 * never swallowed by the fallback path — it must propagate to the route handler.
 */
export declare function reframeText(text: string, framework: string, options?: {
    allowFallback?: boolean;
}): Promise<string>;
/**
 * Extract keyword tags from a journal entry text.
 * Returns an array of 3-5 lowercase keywords/short phrases.
 */
export declare function extractTags(text: string): Promise<string[]>;
/**
 * Generate a concise group-chat facilitator response.
 */
export declare function generateChatBotReply(thinkTankName: string, username: string, message: string): Promise<string>;
//# sourceMappingURL=gemini.d.ts.map