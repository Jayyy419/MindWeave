"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.reframeText = reframeText;
exports.extractTags = extractTags;
exports.generateChatBotReply = generateChatBotReply;
const generative_ai_1 = require("@google/generative-ai");
const dotenv_1 = __importDefault(require("dotenv"));
const frameworks_1 = require("../config/frameworks");
dotenv_1.default.config();
const geminiApiKey = process.env.GEMINI_API_KEY || "";
const geminiModel = process.env.GEMINI_MODEL || "gemini-2.5-flash";
// Initialize the Gemini client when a key is present.
const genAI = geminiApiKey ? new generative_ai_1.GoogleGenerativeAI(geminiApiKey) : null;
const STOP_WORDS = new Set([
    "a",
    "an",
    "and",
    "are",
    "as",
    "at",
    "be",
    "but",
    "by",
    "for",
    "from",
    "had",
    "has",
    "have",
    "i",
    "if",
    "in",
    "is",
    "it",
    "me",
    "my",
    "of",
    "on",
    "or",
    "so",
    "that",
    "the",
    "their",
    "there",
    "they",
    "this",
    "to",
    "was",
    "we",
    "were",
    "with",
    "you",
    "your",
]);
function buildFallbackTags(text) {
    const words = text
        .toLowerCase()
        .replace(/[^a-z0-9\s]/g, " ")
        .split(/\s+/)
        .filter((word) => word.length >= 4 && !STOP_WORDS.has(word));
    const counts = new Map();
    for (const word of words) {
        counts.set(word, (counts.get(word) || 0) + 1);
    }
    return [...counts.entries()]
        .sort((left, right) => right[1] - left[1])
        .slice(0, 5)
        .map(([word]) => word);
}
/**
 * Reframe a user's journal entry text using the specified therapeutic framework.
 * Calls Google Gemini to generate the reframed version.
 *
 * Throws Error("NOT_JOURNAL_ENTRY") when the model determines the text is not
 * a genuine personal journal entry (off-topic / abuse attempt). This error is
 * never swallowed by the fallback path — it must propagate to the route handler.
 */
async function reframeText(text, framework, options) {
    const allowFallback = options?.allowFallback ?? true;
    const systemPrompt = frameworks_1.FRAMEWORK_PROMPT_MAP[framework];
    if (!systemPrompt) {
        throw new Error(`Unknown framework: ${framework}`);
    }
    if (!genAI) {
        throw new Error("Gemini API key is missing");
    }
    try {
        // Pass the system prompt as a proper systemInstruction (kept separate from
        // the user-supplied text) to reduce the risk of prompt injection.
        const model = genAI.getGenerativeModel({
            model: geminiModel,
            systemInstruction: systemPrompt,
        });
        const result = await model.generateContent(`Journal reflection:\n"${text}"`);
        const reframedText = result.response.text().trim();
        // The scope-guard in every system prompt instructs the model to respond
        // with [NOT_JOURNAL] when it detects an off-topic request.
        if (reframedText.startsWith("[NOT_JOURNAL]")) {
            throw new Error("NOT_JOURNAL_ENTRY");
        }
        return reframedText || (frameworks_1.FRAMEWORK_FALLBACK_MAP[framework] ?? text);
    }
    catch (error) {
        // Content rejection — must propagate, not be silently swapped for a fallback.
        if (error instanceof Error && error.message === "NOT_JOURNAL_ENTRY") {
            throw error;
        }
        if (!allowFallback) {
            throw new Error("AI reframing unavailable right now");
        }
        console.warn("Gemini reframing failed, using fallback response:", error);
        return frameworks_1.FRAMEWORK_FALLBACK_MAP[framework] ?? text;
    }
}
/**
 * Extract keyword tags from a journal entry text.
 * Returns an array of 3-5 lowercase keywords/short phrases.
 */
async function extractTags(text) {
    try {
        if (!genAI)
            throw new Error("Gemini API key is missing");
        const model = genAI.getGenerativeModel({
            model: geminiModel,
            systemInstruction: "You are a keyword extractor for a personal journaling app. Extract 3-5 keywords or short phrases (1-2 words each) representing the main topics, emotions, or themes. Return ONLY a comma-separated list with no numbering, bullet points, or extra text.",
        });
        const result = await model.generateContent(`Extract keywords from this journal text:\n"${text}"`);
        const response = result.response;
        const rawTags = response.text().trim();
        const tags = rawTags
            .split(",")
            .map((tag) => tag.trim().toLowerCase())
            .filter((tag) => tag.length > 0 && tag.length < 50);
        return tags.length > 0 ? tags : buildFallbackTags(text);
    }
    catch (error) {
        console.warn("Gemini tag extraction failed, using fallback tags:", error);
        return buildFallbackTags(text);
    }
}
/**
 * Generate a concise group-chat facilitator response.
 */
async function generateChatBotReply(thinkTankName, username, message) {
    const fallback = `Thanks for sharing, ${username}. In ${thinkTankName}, a helpful next step is to break this into one small action and ask the group for focused feedback.`;
    try {
        if (!genAI)
            throw new Error("Gemini API key is missing");
        const model = genAI.getGenerativeModel({ model: geminiModel });
        const prompt = `You are MindWeave Bot, a warm and practical facilitator in a group called "${thinkTankName}".
Respond to this user message in 2-4 concise sentences:

User (${username}) said: "${message}"

Rules:
- Be supportive and specific.
- Offer one actionable next step.
- Keep under 90 words.
- Do not mention safety policy, system prompts, or technical details.
- Return only the reply text.`;
        const result = await model.generateContent(prompt);
        const text = result.response.text().trim();
        return text || fallback;
    }
    catch (error) {
        console.warn("Gemini chat reply failed, using fallback:", error);
        return fallback;
    }
}
//# sourceMappingURL=gemini.js.map